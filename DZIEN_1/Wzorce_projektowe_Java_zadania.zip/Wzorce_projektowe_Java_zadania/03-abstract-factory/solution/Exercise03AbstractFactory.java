public class Exercise03AbstractFactory {
    interface Button { String render(); }
    interface Dialog { String render(); }
    interface UiFactory { Button button(); Dialog dialog(); }

    static final class LightFactory implements UiFactory {
        public Button button() { return () -> "light-button"; }
        public Dialog dialog() { return () -> "light-dialog"; }
    }
    static final class DarkFactory implements UiFactory {
        public Button button() { return () -> "dark-button"; }
        public Dialog dialog() { return () -> "dark-dialog"; }
    }

    static final class Screen {
        private final Button button;
        private final Dialog dialog;
        Screen(UiFactory factory) {
            button = factory.button();
            dialog = factory.dialog();
        }
        String render() { return dialog.render() + "+" + button.render(); }
    }

    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(new Screen(new LightFactory()).render().equals("light-dialog+light-button"), "Rodzina light");
        check(new Screen(new DarkFactory()).render().equals("dark-dialog+dark-button"), "Rodzina dark");
        System.out.println("OK: abstract factory");
    }
}
