import java.util.*;

/**
 * Zapewnij spójność przycisku i okna dialogowego dla dwóch motywów.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise03AbstractFactory.java
 */
public class Exercise03AbstractFactory {
    interface Button { String render(); }
    interface Dialog { String render(); }
    interface UiFactory {
        Button button();
        Dialog dialog();
    }
    static final class Screen {
        Screen(UiFactory factory) { /* TODO */ }
        String render() { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
