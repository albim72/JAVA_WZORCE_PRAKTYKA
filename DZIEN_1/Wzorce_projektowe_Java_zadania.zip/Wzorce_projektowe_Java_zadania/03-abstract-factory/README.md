# 03. Abstract Factory — spójna rodzina komponentów UI

**Wzorce / zasady:** Abstract Factory  
**Czas:** 30–40 min  
**Punkt wyjścia:** Zapewnij spójność przycisku i okna dialogowego dla dwóch motywów.

## Zadanie

1. Zdefiniuj Button, Dialog oraz UiFactory.
2. Zaimplementuj LightFactory i DarkFactory.
3. Nie przekazuj motywu do pojedynczych komponentów.
4. Sprawdź, że Screen renderuje wyłącznie spójną rodzinę.

## Kryteria akceptacji

- Klient zna tylko UiFactory.
- Dodanie nowej rodziny nie zmienia klasy Screen.
- Program kończy się komunikatem OK: abstract factory.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise03AbstractFactory.java
```
