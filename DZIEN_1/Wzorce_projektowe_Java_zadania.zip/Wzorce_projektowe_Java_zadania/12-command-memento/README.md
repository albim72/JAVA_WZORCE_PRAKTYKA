# 12. Command i Memento — kolejka operacji oraz undo

**Wzorce / zasady:** Command, Memento  
**Czas:** 50–65 min  
**Punkt wyjścia:** Zamień operację w obiekt i odtwarzaj poprzedni stan bez ujawniania wnętrza edytora.

## Zadanie

1. Zdefiniuj Command z execute() i undo().
2. Zaimplementuj AppendCommand działający na Editor.
3. Niech Editor tworzy i odtwarza nieprzezroczyste Memento.
4. Dodaj CommandBus przechowujący historię wykonanych poleceń.

## Kryteria akceptacji

- Polecenia można wykonać z kolejki.
- Undo przywraca poprzedni tekst bez kopiowania pól edytora w CommandBus.
- Program kończy się komunikatem OK: command + memento.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise12CommandMemento.java
```
