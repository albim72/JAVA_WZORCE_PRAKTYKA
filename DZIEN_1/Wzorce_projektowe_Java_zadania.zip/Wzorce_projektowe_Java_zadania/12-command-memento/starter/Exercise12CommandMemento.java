import java.util.*;

/**
 * Zamień operację w obiekt i odtwarzaj poprzedni stan bez ujawniania wnętrza edytora.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise12CommandMemento.java
 */
public class Exercise12CommandMemento {
    interface Command { void execute(); void undo(); }
    static final class Editor {
        private String text = "";
        record Memento(String state) { }
        Memento snapshot() { throw new UnsupportedOperationException("TODO"); }
        void restore(Memento memento) { /* TODO */ }
        void append(String value) { /* TODO */ }
        String text() { return text; }
    }
    static final class AppendCommand implements Command { /* TODO */
        public void execute() { throw new UnsupportedOperationException("TODO"); }
        public void undo() { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
