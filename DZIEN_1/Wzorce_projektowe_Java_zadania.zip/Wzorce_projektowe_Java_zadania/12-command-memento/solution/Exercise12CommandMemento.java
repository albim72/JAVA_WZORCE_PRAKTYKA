import java.util.*;

public class Exercise12CommandMemento {
    interface Command { void execute(); void undo(); }
    static final class Editor {
        private String text = "";
        record Memento(String state) { }
        Memento snapshot() { return new Memento(text); }
        void restore(Memento memento) { text = memento.state(); }
        void append(String value) { text += value; }
        String text() { return text; }
    }
    static final class AppendCommand implements Command {
        private final Editor editor;
        private final String value;
        private Editor.Memento before;
        AppendCommand(Editor editor, String value) { this.editor = editor; this.value = value; }
        public void execute() { before = editor.snapshot(); editor.append(value); }
        public void undo() { if (before != null) editor.restore(before); }
    }
    static final class CommandBus {
        private final Deque<Command> queue = new ArrayDeque<>();
        private final Deque<Command> history = new ArrayDeque<>();
        void enqueue(Command command) { queue.add(command); }
        void runAll() { while (!queue.isEmpty()) { Command c = queue.remove(); c.execute(); history.push(c); } }
        void undoLast() { if (!history.isEmpty()) history.pop().undo(); }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var editor = new Editor();
        var bus = new CommandBus();
        bus.enqueue(new AppendCommand(editor, "wzorce "));
        bus.enqueue(new AppendCommand(editor, "projektowe"));
        bus.runAll();
        check(editor.text().equals("wzorce projektowe"), "Wykonanie kolejki");
        bus.undoLast();
        check(editor.text().equals("wzorce "), "Undo");
        System.out.println("OK: command + memento");
    }
}
