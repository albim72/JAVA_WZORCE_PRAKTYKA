# 04. Builder — bezpieczna konstrukcja żądania HTTP

**Wzorce / zasady:** Builder, immutable object  
**Czas:** 40–50 min  
**Punkt wyjścia:** Zastąp konstruktor teleskopowy czytelnym builderem z walidacją.

## Zadanie

1. Zaprojektuj niemutowalny HttpRequest.
2. Dodaj fluent API: uri(), method(), header(), timeoutMs().
3. Waliduj wymagane URI, dodatni timeout i dozwolone metody.
4. Zadbaj, aby mapa nagłówków nie wyciekała na zewnątrz.

## Kryteria akceptacji

- Nie da się zbudować obiektu bez URI.
- Zmiana mapy wejściowej nie zmienia zbudowanego obiektu.
- Program kończy się komunikatem OK: builder.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise04Builder.java
```
