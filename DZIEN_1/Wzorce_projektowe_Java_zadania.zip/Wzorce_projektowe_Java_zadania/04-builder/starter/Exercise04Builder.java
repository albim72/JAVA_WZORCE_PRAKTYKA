import java.util.*;

/**
 * Zastąp konstruktor teleskopowy czytelnym builderem z walidacją.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise04Builder.java
 */
public class Exercise04Builder {
    static final class HttpRequest {
        // TODO: niemutowalne pola
        static Builder builder() { return new Builder(); }
        static final class Builder {
            Builder uri(String uri) { return this; }
            Builder method(String method) { return this; }
            Builder header(String name, String value) { return this; }
            Builder timeoutMs(int timeoutMs) { return this; }
            HttpRequest build() { throw new UnsupportedOperationException("TODO"); }
        }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
