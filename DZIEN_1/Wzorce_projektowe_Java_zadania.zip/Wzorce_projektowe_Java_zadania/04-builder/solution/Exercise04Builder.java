import java.util.*;

public class Exercise04Builder {
    static final class HttpRequest {
        private final String uri;
        private final String method;
        private final Map<String, String> headers;
        private final int timeoutMs;

        private HttpRequest(Builder b) {
            uri = b.uri;
            method = b.method;
            headers = Map.copyOf(b.headers);
            timeoutMs = b.timeoutMs;
        }
        static Builder builder() { return new Builder(); }
        String uri() { return uri; }
        String method() { return method; }
        Map<String, String> headers() { return headers; }
        int timeoutMs() { return timeoutMs; }

        static final class Builder {
            private String uri;
            private String method = "GET";
            private final Map<String, String> headers = new LinkedHashMap<>();
            private int timeoutMs = 1_000;
            Builder uri(String value) { uri = value; return this; }
            Builder method(String value) { method = value; return this; }
            Builder header(String name, String value) { headers.put(name, value); return this; }
            Builder timeoutMs(int value) { timeoutMs = value; return this; }
            HttpRequest build() {
                if (uri == null || uri.isBlank()) throw new IllegalStateException("URI jest wymagane");
                if (!Set.of("GET", "POST", "PUT", "DELETE").contains(method)) throw new IllegalStateException("Metoda");
                if (timeoutMs <= 0) throw new IllegalStateException("Timeout");
                return new HttpRequest(this);
            }
        }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var request = HttpRequest.builder().uri("https://example.test").method("POST")
            .header("X-Trace", "abc").timeoutMs(2_000).build();
        check(request.method().equals("POST") && request.headers().get("X-Trace").equals("abc"), "Dane");
        try { request.headers().put("X", "Y"); throw new AssertionError("Mapa jest modyfikowalna"); }
        catch (UnsupportedOperationException expected) { }
        System.out.println("OK: builder");
    }
}
