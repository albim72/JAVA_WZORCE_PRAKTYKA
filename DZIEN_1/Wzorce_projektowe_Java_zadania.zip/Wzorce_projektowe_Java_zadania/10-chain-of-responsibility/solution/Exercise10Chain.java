import java.util.*;

public class Exercise10Chain {
    record Transaction(long amount, String country, int fraudScore) { }
    static abstract class Handler {
        private Handler next;
        Handler linkWith(Handler next) { this.next = next; return next; }
        final String handle(Transaction tx) {
            String result = check(tx);
            if (!result.equals("OK")) return result;
            return next == null ? "OK" : next.handle(tx);
        }
        protected abstract String check(Transaction tx);
    }
    static final class AmountHandler extends Handler {
        protected String check(Transaction tx) { return tx.amount() <= 10_000 ? "OK" : "AMOUNT"; }
    }
    static final class CountryHandler extends Handler {
        private final Set<String> allowed;
        CountryHandler(Set<String> allowed) { this.allowed = allowed; }
        protected String check(Transaction tx) { return allowed.contains(tx.country()) ? "OK" : "COUNTRY"; }
    }
    static final class FraudScoreHandler extends Handler {
        protected String check(Transaction tx) { return tx.fraudScore() < 70 ? "OK" : "FRAUD"; }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        Handler root = new AmountHandler();
        root.linkWith(new CountryHandler(Set.of("PL", "DE"))).linkWith(new FraudScoreHandler());
        check(root.handle(new Transaction(5000, "PL", 20)).equals("OK"), "Akceptacja");
        check(root.handle(new Transaction(15000, "PL", 20)).equals("AMOUNT"), "Kwota");
        check(root.handle(new Transaction(5000, "XX", 20)).equals("COUNTRY"), "Kraj");
        check(root.handle(new Transaction(5000, "PL", 90)).equals("FRAUD"), "Fraud");
        System.out.println("OK: chain");
    }
}
