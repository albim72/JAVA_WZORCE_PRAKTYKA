# 10. Chain of Responsibility — walidacja transakcji

**Wzorce / zasady:** Chain of Responsibility  
**Czas:** 35–45 min  
**Punkt wyjścia:** Zbuduj konfigurowalny łańcuch reguł zatrzymujący pierwsze odrzucenie.

## Zadanie

1. Zdefiniuj abstrakcyjny Handler z metodą linkWith().
2. Dodaj AmountHandler, CountryHandler i FraudScoreHandler.
3. Każdy handler podejmuje decyzję tylko w swoim zakresie.
4. Przetestuj akceptację oraz trzy niezależne powody odrzucenia.

## Kryteria akceptacji

- Kolejność handlerów można zmienić przy składaniu łańcucha.
- Po odrzuceniu dalsze elementy nie są wykonywane.
- Program kończy się komunikatem OK: chain.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise10Chain.java
```
