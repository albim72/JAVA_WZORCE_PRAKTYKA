import java.util.*;

/**
 * Zbuduj konfigurowalny łańcuch reguł zatrzymujący pierwsze odrzucenie.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise10Chain.java
 */
public class Exercise10Chain {
    record Transaction(long amount, String country, int fraudScore) { }
    static abstract class Handler {
        Handler linkWith(Handler next) { return this; /* TODO */ }
        final String handle(Transaction tx) { throw new UnsupportedOperationException("TODO"); }
        protected abstract String check(Transaction tx);
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
