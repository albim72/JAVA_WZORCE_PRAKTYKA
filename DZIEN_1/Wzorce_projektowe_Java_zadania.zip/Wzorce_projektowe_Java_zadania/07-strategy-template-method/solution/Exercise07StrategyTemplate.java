public class Exercise07StrategyTemplate {
    interface PricingStrategy { double price(double base); }
    static final class RegularPricing implements PricingStrategy {
        public double price(double base) { return base; }
    }
    static final class WeekendPricing implements PricingStrategy {
        public double price(double base) { return base * 0.85; }
    }
    static abstract class CheckoutWorkflow {
        private final PricingStrategy pricing;
        CheckoutWorkflow(PricingStrategy pricing) { this.pricing = pricing; }
        final String process(double base) {
            double amount = pricing.price(base);
            return reserve() + ">pay:" + amount + ">" + afterPayment();
        }
        protected abstract String reserve();
        protected String afterPayment() { return "notify"; }
    }
    static final class DigitalCheckout extends CheckoutWorkflow {
        DigitalCheckout(PricingStrategy pricing) { super(pricing); }
        protected String reserve() { return "license"; }
        protected String afterPayment() { return "email-link"; }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var flow = new DigitalCheckout(new WeekendPricing());
        check(flow.process(100).equals("license>pay:85.0>email-link"), "Przepływ");
        System.out.println("OK: strategy + template");
    }
}
