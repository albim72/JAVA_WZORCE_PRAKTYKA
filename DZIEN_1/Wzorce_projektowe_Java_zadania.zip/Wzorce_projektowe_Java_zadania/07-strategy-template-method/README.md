# 07. Strategy i Template Method — kalkulacja i stabilny workflow

**Wzorce / zasady:** Strategy, Template Method  
**Czas:** 40–50 min  
**Punkt wyjścia:** Wstrzyknij algorytm ceny i ustabilizuj kolejność kroków realizacji.

## Zadanie

1. Zdefiniuj PricingStrategy z dwiema wymiennymi implementacjami.
2. Zbuduj abstrakcyjny CheckoutWorkflow z finalną metodą process().
3. Pozostaw jeden krok jako metodę abstrakcyjną, a drugi jako hook.
4. Sprawdź kolejność kroków oraz wymianę strategii bez dziedziczenia.

## Kryteria akceptacji

- Cena zależy od wstrzykniętej strategii.
- Podklasa nie może zmienić kolejności procesu.
- Program kończy się komunikatem OK: strategy + template.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise07StrategyTemplate.java
```
