import java.util.*;

/**
 * Wstrzyknij algorytm ceny i ustabilizuj kolejność kroków realizacji.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise07StrategyTemplate.java
 */
public class Exercise07StrategyTemplate {
    interface PricingStrategy { double price(double base); }
    static abstract class CheckoutWorkflow {
        final String process(double base) { throw new UnsupportedOperationException("TODO"); }
        protected abstract String reserve();
        protected String afterPayment() { return "notify"; }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
