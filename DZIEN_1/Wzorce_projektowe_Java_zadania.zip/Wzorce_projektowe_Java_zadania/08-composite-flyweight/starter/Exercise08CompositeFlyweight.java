import java.util.*;

/**
 * Obsłuż element i grupę jednym kontraktem, współdzieląc ciężki styl.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise08CompositeFlyweight.java
 */
public class Exercise08CompositeFlyweight {
    interface Node { String render(); int size(); }
    record Style(String font, int size) { }
    static final class StyleFactory { static Style get(String font, int size) { throw new UnsupportedOperationException("TODO"); } }
    static final class TextNode implements Node { /* TODO */
        public String render() { throw new UnsupportedOperationException("TODO"); }
        public int size() { return 1; }
    }
    static final class Group implements Node { /* TODO */
        public String render() { throw new UnsupportedOperationException("TODO"); }
        public int size() { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
