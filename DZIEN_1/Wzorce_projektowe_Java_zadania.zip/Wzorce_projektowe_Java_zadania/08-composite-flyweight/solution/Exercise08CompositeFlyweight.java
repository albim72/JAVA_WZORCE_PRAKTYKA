import java.util.*;

public class Exercise08CompositeFlyweight {
    interface Node { String render(); int size(); }
    record Style(String font, int size) { }
    static final class StyleFactory {
        private static final Map<String, Style> CACHE = new HashMap<>();
        static Style get(String font, int size) {
            return CACHE.computeIfAbsent(font + ":" + size, k -> new Style(font, size));
        }
    }
    static final class TextNode implements Node {
        private final String text;
        private final Style style;
        TextNode(String text, Style style) { this.text = text; this.style = style; }
        Style style() { return style; }
        public String render() { return style.font() + ":" + text; }
        public int size() { return 1; }
    }
    static final class Group implements Node {
        private final List<Node> children = new ArrayList<>();
        Group add(Node node) { children.add(node); return this; }
        public String render() { return children.stream().map(Node::render).reduce((a,b) -> a + "|" + b).orElse(""); }
        public int size() { return children.stream().mapToInt(Node::size).sum(); }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var a = new TextNode("A", StyleFactory.get("Inter", 12));
        var b = new TextNode("B", StyleFactory.get("Inter", 12));
        var root = new Group().add(a).add(new Group().add(b));
        check(root.size() == 2 && root.render().equals("Inter:A|Inter:B"), "Composite");
        check(a.style() == b.style(), "Flyweight");
        System.out.println("OK: composite + flyweight");
    }
}
