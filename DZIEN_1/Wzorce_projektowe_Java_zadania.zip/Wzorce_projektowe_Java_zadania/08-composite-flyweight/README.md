# 08. Composite i Flyweight — drzewo dokumentu bez nadmiaru pamięci

**Wzorce / zasady:** Composite, Flyweight, JCF  
**Czas:** 45–60 min  
**Punkt wyjścia:** Obsłuż element i grupę jednym kontraktem, współdzieląc ciężki styl.

## Zadanie

1. Zdefiniuj Node z metodami render() i size().
2. Utwórz TextNode oraz Group przechowujący dzieci w ArrayList.
3. Zbuduj StyleFactory cache'ujący style według klucza.
4. Potwierdź tożsamość współdzielonych obiektów Style.

## Kryteria akceptacji

- Klient wywołuje to samo API dla liścia i kompozytu.
- Dwa węzły o tym samym stylu używają jednej instancji Style.
- Program kończy się komunikatem OK: composite + flyweight.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise08CompositeFlyweight.java
```
