import java.util.*;

public class Exercise01Solid {
    interface DiscountPolicy { double apply(double total); }
    interface ReceiptRepository { void save(double paid); }
    interface Notifier { void send(String message); }

    static final class StandardDiscount implements DiscountPolicy {
        public double apply(double total) { return total; }
    }

    static final class VipDiscount implements DiscountPolicy {
        public double apply(double total) { return total * 0.90; }
    }

    static final class InMemoryReceiptRepository implements ReceiptRepository {
        final List<Double> saved = new ArrayList<>();
        public void save(double paid) { saved.add(paid); }
    }

    static final class RecordingNotifier implements Notifier {
        final List<String> messages = new ArrayList<>();
        public void send(String message) { messages.add(message); }
    }

    static final class CheckoutService {
        private final DiscountPolicy discount;
        private final ReceiptRepository receipts;
        private final Notifier notifier;

        CheckoutService(DiscountPolicy discount, ReceiptRepository receipts, Notifier notifier) {
            this.discount = discount;
            this.receipts = receipts;
            this.notifier = notifier;
        }

        double checkout(double total) {
            double paid = discount.apply(total);
            receipts.save(paid);
            notifier.send("Zapłacono: " + paid);
            return paid;
        }
    }

    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        var repo = new InMemoryReceiptRepository();
        var notifier = new RecordingNotifier();
        var service = new CheckoutService(new VipDiscount(), repo, notifier);
        check(Math.abs(service.checkout(100) - 90) < 0.001, "Błędny rabat VIP");
        check(repo.saved.equals(List.of(90.0)), "Brak zapisu paragonu");
        check(notifier.messages.size() == 1, "Brak powiadomienia");
        System.out.println("OK: SOLID");
    }
}
