import java.util.*;

/**
 * Rozbij monolityczny checkout na politykę rabatu, repozytorium i kanał powiadomień.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise01Solid.java
 */
public class Exercise01Solid {
    interface DiscountPolicy { double apply(double total); }
    interface ReceiptRepository { void save(double paid); }
    interface Notifier { void send(String message); }

    static final class CheckoutService {
        // TODO: pola i konstruktor z zależnościami
        double checkout(double total) { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
