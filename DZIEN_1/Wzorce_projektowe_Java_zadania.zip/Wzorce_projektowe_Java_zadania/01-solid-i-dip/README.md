# 01. SOLID i DIP — refaktoryzacja procesu zamówienia

**Wzorce / zasady:** SRP, OCP, DIP, ISP  
**Czas:** 35–45 min  
**Punkt wyjścia:** Rozbij monolityczny checkout na politykę rabatu, repozytorium i kanał powiadomień.

## Zadanie

1. Zdefiniuj małe kontrakty DiscountPolicy, ReceiptRepository i Notifier.
2. Wstrzyknij zależności do CheckoutService przez konstruktor.
3. Dodaj StandardDiscount oraz VipDiscount bez modyfikowania CheckoutService.
4. Napisz testy w main: cena VIP, zapis paragonu i wysłanie komunikatu.

## Kryteria akceptacji

- CheckoutService nie tworzy implementacji technicznych.
- Nowy rabat nie wymaga zmiany klasy usługi.
- Program kończy się komunikatem OK: SOLID.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise01Solid.java
```
