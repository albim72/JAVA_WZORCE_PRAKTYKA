# Capstone — przepływ zamówienia bez przecieku szczegółów

## Cel

Zaprojektuj mały system realizacji zamówień. Nie próbuj używać wszystkich wzorców. Najpierw przypisz problem, siłę zmiany i koszt alternatywy.

## Wymagania domenowe

- zamówienie przechodzi przez `NEW → PAID → SHIPPED` albo `CANCELLED`,
- przed płatnością działa konfigurowalny łańcuch reguł ryzyka,
- kanał płatności powstaje z fabryki,
- cena zależy od wymiennej strategii,
- opłacenie zamówienia publikuje zdarzenie do co najmniej dwóch odbiorców,
- operator może cofnąć ostatnią operację administracyjną,
- klient aplikacji widzi jedno proste API fasady.

## Ograniczenia

- Java 17+, bez bibliotek zewnętrznych,
- testy akceptacyjne umieść w `main`,
- żadna klasa domenowa nie może tworzyć klienta infrastruktury przez `new`,
- nie stosuj Singletona jako globalnego kontenera usług.

## Kryteria oceny

| Obszar | Pytanie kontrolne |
|---|---|
| Trafność | Czy każdy wzorzec odpowiada na nazwany problem? |
| Granice | Czy szczegóły techniczne nie przeciekają do domeny? |
| Zmiana | Czy dodanie wariantu wymaga rozszerzenia zamiast edycji rdzenia? |
| Testy | Czy reguły można sprawdzić bez sieci i bazy danych? |
| Prostota | Czy da się usunąć wzorzec bez pogorszenia projektu? |

## Retrospektywa

Przygotuj trzyminutową obronę architektury: jeden świadomy wybór, jeden odrzucony wzorzec i jedno miejsce, które refaktoryzowałbyś przy następnym wymaganiu.
