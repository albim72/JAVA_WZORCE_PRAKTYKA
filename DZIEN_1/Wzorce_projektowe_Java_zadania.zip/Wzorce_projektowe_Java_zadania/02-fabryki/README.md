# 02. Simple Factory i Factory Method — kanały kampanii

**Wzorce / zasady:** Simple Factory, Factory Method  
**Czas:** 35–45 min  
**Punkt wyjścia:** Oddziel wybór kanału od procesu wysyłania kampanii.

## Zadanie

1. Utwórz Notification oraz implementacje EmailNotification i SmsNotification.
2. Zaimplementuj NotificationFactory jako prosty centralny wybór.
3. Zbuduj klasę bazową Campaign z metodą fabrykującą createNotification().
4. Porównaj miejsca rozszerzania obu wariantów.

## Kryteria akceptacji

- Simple Factory odtwarza EMAIL i SMS.
- EmailCampaign oraz SmsCampaign nie duplikują algorytmu send().
- Program kończy się komunikatem OK: factories.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise02Factories.java
```
