import java.util.*;

/**
 * Oddziel wybór kanału od procesu wysyłania kampanii.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise02Factories.java
 */
public class Exercise02Factories {
    enum Channel { EMAIL, SMS }
    interface Notification { String deliver(String message); }
    static final class NotificationFactory {
        static Notification create(Channel channel) { throw new UnsupportedOperationException("TODO"); }
    }
    static abstract class Campaign {
        protected abstract Notification createNotification();
        String send(String message) { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
