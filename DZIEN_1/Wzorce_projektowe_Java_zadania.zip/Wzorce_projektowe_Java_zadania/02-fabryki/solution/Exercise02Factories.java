public class Exercise02Factories {
    enum Channel { EMAIL, SMS }
    interface Notification { String deliver(String message); }

    static final class EmailNotification implements Notification {
        public String deliver(String message) { return "EMAIL:" + message; }
    }
    static final class SmsNotification implements Notification {
        public String deliver(String message) { return "SMS:" + message; }
    }

    static final class NotificationFactory {
        static Notification create(Channel channel) {
            return switch (channel) {
                case EMAIL -> new EmailNotification();
                case SMS -> new SmsNotification();
            };
        }
    }

    static abstract class Campaign {
        protected abstract Notification createNotification();
        String send(String message) { return createNotification().deliver(message); }
    }
    static final class EmailCampaign extends Campaign {
        protected Notification createNotification() { return new EmailNotification(); }
    }
    static final class SmsCampaign extends Campaign {
        protected Notification createNotification() { return new SmsNotification(); }
    }

    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(NotificationFactory.create(Channel.EMAIL).deliver("A").equals("EMAIL:A"), "Simple Factory");
        check(new SmsCampaign().send("B").equals("SMS:B"), "Factory Method");
        System.out.println("OK: factories");
    }
}
