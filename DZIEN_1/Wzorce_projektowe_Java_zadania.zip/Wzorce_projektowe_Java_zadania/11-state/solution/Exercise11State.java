public class Exercise11State {
    interface OrderState {
        void pay(Order order); void ship(Order order); void cancel(Order order); String name();
    }
    static abstract class BaseState implements OrderState {
        public void pay(Order order) { illegal("pay"); }
        public void ship(Order order) { illegal("ship"); }
        public void cancel(Order order) { illegal("cancel"); }
        void illegal(String action) { throw new IllegalStateException(action + " niedozwolone w " + name()); }
    }
    static final class NewState extends BaseState {
        public String name() { return "NEW"; }
        public void pay(Order order) { order.transition(new PaidState()); }
        public void cancel(Order order) { order.transition(new CancelledState()); }
    }
    static final class PaidState extends BaseState {
        public String name() { return "PAID"; }
        public void ship(Order order) { order.transition(new ShippedState()); }
        public void cancel(Order order) { order.transition(new CancelledState()); }
    }
    static final class ShippedState extends BaseState { public String name() { return "SHIPPED"; } }
    static final class CancelledState extends BaseState { public String name() { return "CANCELLED"; } }
    static final class Order {
        private OrderState state = new NewState();
        void transition(OrderState next) { state = next; }
        void pay() { state.pay(this); }
        void ship() { state.ship(this); }
        void cancel() { state.cancel(this); }
        String state() { return state.name(); }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var order = new Order();
        order.pay(); order.ship();
        check(order.state().equals("SHIPPED"), "Przejścia");
        try { order.cancel(); throw new AssertionError("Niedozwolone przejście"); }
        catch (IllegalStateException expected) { }
        System.out.println("OK: state");
    }
}
