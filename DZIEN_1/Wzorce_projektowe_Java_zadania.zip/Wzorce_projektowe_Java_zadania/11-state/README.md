# 11. State — cykl życia zamówienia bez rozrastających się ifów

**Wzorce / zasady:** State  
**Czas:** 40–50 min  
**Punkt wyjścia:** Przenieś legalne przejścia i zachowania do jawnych obiektów stanu.

## Zadanie

1. Zdefiniuj OrderState z operacjami pay(), ship() i cancel().
2. Utwórz NewState, PaidState, ShippedState i CancelledState.
3. Niech kontekst deleguje działania do bieżącego stanu.
4. Przetestuj legalne i nielegalne przejścia.

## Kryteria akceptacji

- Stan zmienia się wyłącznie przez legalną operację.
- Nielegalna operacja zwraca czytelny wyjątek.
- Program kończy się komunikatem OK: state.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise11State.java
```
