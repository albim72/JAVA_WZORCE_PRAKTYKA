import java.util.*;

/**
 * Przenieś legalne przejścia i zachowania do jawnych obiektów stanu.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise11State.java
 */
public class Exercise11State {
    interface OrderState { void pay(Order order); void ship(Order order); void cancel(Order order); String name(); }
    static final class Order {
        private OrderState state;
        Order() { /* TODO */ }
        void transition(OrderState next) { state = next; }
        void pay() { state.pay(this); }
        void ship() { state.ship(this); }
        void cancel() { state.cancel(this); }
        String state() { return state.name(); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
