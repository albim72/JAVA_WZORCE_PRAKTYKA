# 05. Adapter i Façade — ochrona domeny przed systemem legacy

**Wzorce / zasady:** Adapter, Façade  
**Czas:** 45–55 min  
**Punkt wyjścia:** Dopasuj kontrakt płatności i ukryj orkiestrację checkoutu za prostym API.

## Zadanie

1. Zdefiniuj PaymentGateway przyjmujący kwotę w złotych.
2. Zaadaptuj LegacyPaymentClient, który oczekuje liczby groszy.
3. Zbuduj CheckoutFacade koordynujący magazyn, płatność i wysyłkę.
4. Zadbaj, aby kod klienta nie znał obiektów legacy.

## Kryteria akceptacji

- Adapter poprawnie przelicza 12,34 zł na 1234 grosze.
- Façade wystawia jedną metodę placeOrder().
- Program kończy się komunikatem OK: adapter + facade.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise05AdapterFacade.java
```
