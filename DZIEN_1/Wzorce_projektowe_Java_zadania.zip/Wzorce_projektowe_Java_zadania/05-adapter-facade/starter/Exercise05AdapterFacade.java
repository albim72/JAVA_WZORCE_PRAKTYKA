import java.util.*;

/**
 * Dopasuj kontrakt płatności i ukryj orkiestrację checkoutu za prostym API.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise05AdapterFacade.java
 */
public class Exercise05AdapterFacade {
    interface PaymentGateway { String charge(long amountInGrosz); }
    static final class LegacyPaymentClient { String payCents(long cents) { return "legacy:" + cents; } }
    static final class LegacyPaymentAdapter implements PaymentGateway {
        LegacyPaymentAdapter(LegacyPaymentClient client) { /* TODO */ }
        public String charge(long amountInGrosz) { throw new UnsupportedOperationException("TODO"); }
    }
    static final class CheckoutFacade {
        String placeOrder(String sku, long amountInGrosz) { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
