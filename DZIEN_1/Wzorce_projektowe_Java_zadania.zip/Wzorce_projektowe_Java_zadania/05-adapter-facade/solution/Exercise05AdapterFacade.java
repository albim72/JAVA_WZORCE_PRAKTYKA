import java.util.*;

public class Exercise05AdapterFacade {
    interface PaymentGateway { String charge(long amountInGrosz); }
    static final class LegacyPaymentClient {
        long lastCents;
        String payCents(long cents) { lastCents = cents; return "legacy:" + cents; }
    }
    static final class LegacyPaymentAdapter implements PaymentGateway {
        private final LegacyPaymentClient client;
        LegacyPaymentAdapter(LegacyPaymentClient client) { this.client = client; }
        public String charge(long amountInGrosz) { return client.payCents(amountInGrosz); }
    }
    static final class Inventory {
        final List<String> reserved = new ArrayList<>();
        void reserve(String sku) { reserved.add(sku); }
    }
    static final class Shipping {
        String create(String sku) { return "shipment:" + sku; }
    }
    static final class CheckoutFacade {
        private final Inventory inventory;
        private final PaymentGateway payments;
        private final Shipping shipping;
        CheckoutFacade(Inventory inventory, PaymentGateway payments, Shipping shipping) {
            this.inventory = inventory; this.payments = payments; this.shipping = shipping;
        }
        String placeOrder(String sku, long amountInGrosz) {
            inventory.reserve(sku);
            return payments.charge(amountInGrosz) + "+" + shipping.create(sku);
        }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var legacy = new LegacyPaymentClient();
        var inventory = new Inventory();
        var facade = new CheckoutFacade(inventory, new LegacyPaymentAdapter(legacy), new Shipping());
        check(facade.placeOrder("BOOK", 1234).equals("legacy:1234+shipment:BOOK"), "Przepływ");
        check(legacy.lastCents == 1234 && inventory.reserved.equals(List.of("BOOK")), "Adapter lub magazyn");
        System.out.println("OK: adapter + facade");
    }
}
