# Wzorce projektowe w Java — pakiet ćwiczeń

Pakiet zawiera 12 niezależnych zadań do szkolenia. Każde zadanie ma:

- `starter/` — kompilowalny szkielet z miejscami `TODO`,
- `solution/` — przykładowe rozwiązanie z samosprawdzającym `main`,
- `README.md` — cel, kroki, kryteria akceptacji i pytania do retrospektywy.

## Wymagania

- Java 17 lub nowsza,
- brak Maven/Gradle i brak bibliotek zewnętrznych.

Uruchom pojedyncze rozwiązanie:

```bash
java --source 17 01-solid-i-dip/solution/Exercise01Solid.java
```

Uruchom komplet rozwiązań na Linux/macOS:

```bash
./run_solutions.sh
```

Na Windows uruchom `run_solutions.bat`.

## Sugerowany tryb pracy

1. Przeczytaj README zadania i nazwij siłę zmiany.
2. Pracuj wyłącznie w katalogu `starter/`.
3. Najpierw zapisz kryteria akceptacji w `main`, potem implementuj.
4. Porównaj z `solution/` dopiero po retrospektywie.
5. Oceń nie tylko poprawność, lecz również sprzężenie, testowalność i koszt rozszerzenia.

`CAPSTONE.md` zawiera projekt integrujący kilka wzorców. `BONUSY.md` rozszerza zakres o Prototype, Singleton, Resource Pool, Bridge, Interpreter i Visitor.
