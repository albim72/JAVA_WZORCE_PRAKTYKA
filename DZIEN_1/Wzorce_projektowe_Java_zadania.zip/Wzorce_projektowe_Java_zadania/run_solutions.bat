@echo off
setlocal
java --source 17 "01-solid-i-dip\solution\Exercise01Solid.java" || exit /b 1
java --source 17 "02-fabryki\solution\Exercise02Factories.java" || exit /b 1
java --source 17 "03-abstract-factory\solution\Exercise03AbstractFactory.java" || exit /b 1
java --source 17 "04-builder\solution\Exercise04Builder.java" || exit /b 1
java --source 17 "05-adapter-facade\solution\Exercise05AdapterFacade.java" || exit /b 1
java --source 17 "06-decorator-proxy\solution\Exercise06DecoratorProxy.java" || exit /b 1
java --source 17 "07-strategy-template-method\solution\Exercise07StrategyTemplate.java" || exit /b 1
java --source 17 "08-composite-flyweight\solution\Exercise08CompositeFlyweight.java" || exit /b 1
java --source 17 "09-observer-mediator\solution\Exercise09ObserverMediator.java" || exit /b 1
java --source 17 "10-chain-of-responsibility\solution\Exercise10Chain.java" || exit /b 1
java --source 17 "11-state\solution\Exercise11State.java" || exit /b 1
java --source 17 "12-command-memento\solution\Exercise12CommandMemento.java" || exit /b 1
echo Wszystkie rozwiazania zakonczyly sie powodzeniem.
