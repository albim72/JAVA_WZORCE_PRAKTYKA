import java.util.*;

/**
 * Dodaj szyfrowanie bez zmiany magazynu i kontroluj odczyt przez zastępcę.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise06DecoratorProxy.java
 */
public class Exercise06DecoratorProxy {
    interface DataSource { void write(String value); String read(); }
    static final class MemoryDataSource implements DataSource {
        String raw; public void write(String value) { raw = value; } public String read() { return raw; }
    }
    static final class EncryptingDecorator implements DataSource { /* TODO */
        public void write(String value) { throw new UnsupportedOperationException("TODO"); }
        public String read() { throw new UnsupportedOperationException("TODO"); }
    }
    static final class AuthorizationProxy implements DataSource { /* TODO */
        public void write(String value) { throw new UnsupportedOperationException("TODO"); }
        public String read() { throw new UnsupportedOperationException("TODO"); }
    }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
