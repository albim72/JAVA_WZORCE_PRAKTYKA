import java.nio.charset.StandardCharsets;
import java.util.*;

public class Exercise06DecoratorProxy {
    interface DataSource { void write(String value); String read(); }
    static final class MemoryDataSource implements DataSource {
        String raw;
        public void write(String value) { raw = value; }
        public String read() { return raw; }
    }
    static final class EncryptingDecorator implements DataSource {
        private final DataSource delegate;
        EncryptingDecorator(DataSource delegate) { this.delegate = delegate; }
        public void write(String value) {
            delegate.write(Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8)));
        }
        public String read() {
            return new String(Base64.getDecoder().decode(delegate.read()), StandardCharsets.UTF_8);
        }
    }
    static final class AuthorizationProxy implements DataSource {
        private final DataSource delegate;
        private final String role;
        AuthorizationProxy(DataSource delegate, String role) { this.delegate = delegate; this.role = role; }
        public void write(String value) { delegate.write(value); }
        public String read() {
            if (!role.equals("ADMIN")) throw new SecurityException("Brak dostępu");
            return delegate.read();
        }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var memory = new MemoryDataSource();
        DataSource encrypted = new EncryptingDecorator(memory);
        encrypted.write("sekret");
        check(!memory.raw.equals("sekret") && encrypted.read().equals("sekret"), "Decorator");
        DataSource guest = new AuthorizationProxy(encrypted, "GUEST");
        try { guest.read(); throw new AssertionError("Proxy nie zablokował odczytu"); }
        catch (SecurityException expected) { }
        check(new AuthorizationProxy(encrypted, "ADMIN").read().equals("sekret"), "Proxy ADMIN");
        System.out.println("OK: decorator + proxy");
    }
}
