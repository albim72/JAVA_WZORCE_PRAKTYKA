# 06. Decorator i Proxy — funkcje warstwowe oraz kontrola dostępu

**Wzorce / zasady:** Decorator, Proxy  
**Czas:** 45–55 min  
**Punkt wyjścia:** Dodaj szyfrowanie bez zmiany magazynu i kontroluj odczyt przez zastępcę.

## Zadanie

1. Utwórz DataSource oraz MemoryDataSource.
2. Dodaj EncryptingDecorator, który modyfikuje zapis i odczyt.
3. Dodaj AuthorizationProxy blokujący odczyt bez roli ADMIN.
4. Zwróć uwagę: oba obiekty opakowują ten sam kontrakt, ale mają inną intencję.

## Kryteria akceptacji

- Surowa wartość w pamięci nie jest tekstem jawnym.
- Użytkownik bez roli ADMIN otrzymuje wyjątek.
- Program kończy się komunikatem OK: decorator + proxy.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise06DecoratorProxy.java
```
