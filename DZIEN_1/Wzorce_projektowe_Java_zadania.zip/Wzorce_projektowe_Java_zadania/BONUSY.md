# Zadania dodatkowe

## Prototype — bezpieczne kopiowanie konfiguracji

Skopiuj szablon raportu zawierający listę sekcji i mapę ustawień. Udowodnij testem, że zmiana kopii nie mutuje prototypu. Porównaj kopię płytką z głęboką.

## Singleton — testowalna polityka instancji

Zaimplementuj bezpieczną dla wielu wątków inicjalizację konfiguracji, a potem opisz, dlaczego globalny dostęp utrudnia testy. Zaproponuj wariant z zakresem życia zarządzanym przez kontener aplikacji.

## Resource Pool — dzierżawa i zwrot

Zbuduj pulę maksymalnie dwóch kosztownych zasobów. Użyj `AutoCloseable`, limitu czasu i bloku `try-with-resources`. Przetestuj zwrot po wyjątku.

## Bridge — format kontra kanał

Oddziel abstrakcję raportu od implementacji renderera. Dodaj `SalesReport` i `AuditReport` oraz `HtmlRenderer` i `TextRenderer` bez mnożenia podklas przez iloczyn wariantów.

## Interpreter — mały język reguł

Zinterpretuj wyrażenia `country == PL AND amount < 10000`. Ogranicz gramatykę, zbuduj drzewo AST i oddziel parsowanie od interpretacji.

## Visitor — nowe operacje na stabilnym drzewie

Dla drzewa `TextNode`, `ImageNode`, `Group` dodaj `ExportVisitor` i `MetricsVisitor`. Oceń koszt dodania nowego typu węzła i nowej operacji.
