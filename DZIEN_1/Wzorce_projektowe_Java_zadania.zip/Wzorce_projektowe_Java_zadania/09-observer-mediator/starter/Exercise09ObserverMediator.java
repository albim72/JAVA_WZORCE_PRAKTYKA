import java.util.*;

/**
 * Rozsyłaj zdarzenia przez centralny mediator bez łączenia nadawców z odbiorcami.
 *
 * Uruchom po uzupełnieniu:
 *   java --source 17 Exercise09ObserverMediator.java
 */
public class Exercise09ObserverMediator {
    record Event(String type, String payload) { }
    interface EventListener { void on(Event event); }
    static final class EventMediator {
        void subscribe(String type, EventListener listener) { /* TODO */ }
        void unsubscribe(String type, EventListener listener) { /* TODO */ }
        void publish(Event event) { /* TODO */ }
    }
    static final class OrderService { void pay(String id) { /* TODO */ } }

    public static void main(String[] args) {
        throw new UnsupportedOperationException(
            "TODO: uzupełnij implementację zgodnie z README, potem zastąp ten wyjątek testami akceptacyjnymi"
        );
    }
}
