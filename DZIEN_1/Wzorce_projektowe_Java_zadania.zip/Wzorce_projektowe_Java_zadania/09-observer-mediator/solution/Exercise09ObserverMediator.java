import java.util.*;

public class Exercise09ObserverMediator {
    record Event(String type, String payload) { }
    interface EventListener { void on(Event event); }
    static final class EventMediator {
        private final Map<String, List<EventListener>> listeners = new HashMap<>();
        void subscribe(String type, EventListener listener) {
            listeners.computeIfAbsent(type, key -> new ArrayList<>()).add(listener);
        }
        void unsubscribe(String type, EventListener listener) {
            listeners.getOrDefault(type, List.of()).remove(listener);
        }
        void publish(Event event) {
            List.copyOf(listeners.getOrDefault(event.type(), List.of())).forEach(l -> l.on(event));
        }
    }
    static final class OrderService {
        private final EventMediator mediator;
        OrderService(EventMediator mediator) { this.mediator = mediator; }
        void pay(String id) { mediator.publish(new Event("OrderPaid", id)); }
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        var mediator = new EventMediator();
        var log = new ArrayList<String>();
        EventListener warehouse = e -> log.add("warehouse:" + e.payload());
        EventListener mail = e -> log.add("mail:" + e.payload());
        mediator.subscribe("OrderPaid", warehouse);
        mediator.subscribe("OrderPaid", mail);
        new OrderService(mediator).pay("42");
        check(log.equals(List.of("warehouse:42", "mail:42")), "Powiadomienia");
        mediator.unsubscribe("OrderPaid", mail);
        new OrderService(mediator).pay("43");
        check(log.size() == 3, "Wypisanie");
        System.out.println("OK: observer + mediator");
    }
}
