# 09. Observer i Mediator — zdarzenia bez bezpośrednich zależności

**Wzorce / zasady:** Observer, Mediator  
**Czas:** 45–55 min  
**Punkt wyjścia:** Rozsyłaj zdarzenia przez centralny mediator bez łączenia nadawców z odbiorcami.

## Zadanie

1. Zdefiniuj EventListener i EventMediator.
2. Pozwól odbiorcom subskrybować wybrany typ zdarzenia.
3. Niech OrderService publikuje OrderPaid bez znajomości odbiorców.
4. Sprawdź kolejność, brak duplikatów i możliwość wypisania subskrypcji.

## Kryteria akceptacji

- OrderService zna wyłącznie mediator.
- Dwa obserwatory otrzymują zdarzenie dokładnie raz.
- Program kończy się komunikatem OK: observer + mediator.

## Retrospektywa

- Jaka dokładnie zmiana uzasadnia użycie wzorca?
- Gdzie przebiega nowa granica odpowiedzialności?
- Jaki koszt i złożoność dodaliśmy?
- W jakiej sytuacji prostsza implementacja byłaby lepsza?

## Uruchomienie rozwiązania referencyjnego

```bash
java --source 17 solution/Exercise09ObserverMediator.java
```
