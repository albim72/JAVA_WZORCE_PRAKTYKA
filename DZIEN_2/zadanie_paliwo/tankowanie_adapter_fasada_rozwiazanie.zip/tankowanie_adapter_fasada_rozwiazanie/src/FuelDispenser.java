public interface FuelDispenser {
    void dispense(double liters);
}
