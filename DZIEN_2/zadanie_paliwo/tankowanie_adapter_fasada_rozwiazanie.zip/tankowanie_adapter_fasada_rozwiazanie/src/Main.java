public class Main {

    public static void main(String[] args) {
        OldFuelPump oldFuelPump = new OldFuelPump();

        FuelDispenser fuelDispenser = new FuelPumpAdapter(oldFuelPump);
        PaymentService paymentService = new PaymentService();
        ReceiptPrinter receiptPrinter = new ReceiptPrinter();

        FuelingFacade fuelingFacade = new FuelingFacade(
                fuelDispenser,
                paymentService,
                receiptPrinter
        );

        fuelingFacade.fuelCar(40.0, 6.50);
    }
}
