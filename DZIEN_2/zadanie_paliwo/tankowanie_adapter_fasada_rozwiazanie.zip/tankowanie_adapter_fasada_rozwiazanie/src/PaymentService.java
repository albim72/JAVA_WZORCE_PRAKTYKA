public class PaymentService {

    public boolean pay(double amount) {
        if (amount <= 0) {
            System.out.println("Błąd płatności: kwota musi być większa od zera.");
            return false;
        }

        System.out.printf("Płatność zaakceptowana: %.2f zł.%n", amount);
        return true;
    }
}
