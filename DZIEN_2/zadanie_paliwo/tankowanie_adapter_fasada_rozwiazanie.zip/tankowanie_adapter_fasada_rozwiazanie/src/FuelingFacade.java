public class FuelingFacade {

    private final FuelDispenser fuelDispenser;
    private final PaymentService paymentService;
    private final ReceiptPrinter receiptPrinter;

    public FuelingFacade(
            FuelDispenser fuelDispenser,
            PaymentService paymentService,
            ReceiptPrinter receiptPrinter
    ) {
        this.fuelDispenser = fuelDispenser;
        this.paymentService = paymentService;
        this.receiptPrinter = receiptPrinter;
    }

    public void fuelCar(double liters, double pricePerLiter) {
        System.out.println("Rozpoczynam tankowanie...");

        double total = liters * pricePerLiter;

        boolean paymentAccepted = paymentService.pay(total);
        if (!paymentAccepted) {
            System.out.println("Tankowanie anulowane.");
            return;
        }

        fuelDispenser.dispense(liters);
        receiptPrinter.print(liters, pricePerLiter, total);

        System.out.println("Tankowanie zakończone.");
    }
}
