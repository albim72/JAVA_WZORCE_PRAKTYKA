public class OldFuelPump {

    public void pumpGallons(double gallons) {
        System.out.printf("Stary dystrybutor wydaje %.2f galonów paliwa.%n", gallons);
    }
}
