public class ReceiptPrinter {

    public void print(double liters, double pricePerLiter, double total) {
        System.out.println("\n===== PARAGON =====");
        System.out.printf("Paliwo: %.2f l%n", liters);
        System.out.printf("Cena za litr: %.2f zł%n", pricePerLiter);
        System.out.printf("Razem: %.2f zł%n", total);
        System.out.println("===================\n");
    }
}
