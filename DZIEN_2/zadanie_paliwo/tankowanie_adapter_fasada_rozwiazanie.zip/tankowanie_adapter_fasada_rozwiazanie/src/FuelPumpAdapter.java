public class FuelPumpAdapter implements FuelDispenser {

    private static final double LITERS_PER_GALLON = 3.78541;
    private final OldFuelPump oldFuelPump;

    public FuelPumpAdapter(OldFuelPump oldFuelPump) {
        this.oldFuelPump = oldFuelPump;
    }

    @Override
    public void dispense(double liters) {
        double gallons = liters / LITERS_PER_GALLON;

        System.out.printf(
                "Adapter: %.2f l = %.2f gal.%n",
                liters,
                gallons
        );

        oldFuelPump.pumpGallons(gallons);
    }
}
