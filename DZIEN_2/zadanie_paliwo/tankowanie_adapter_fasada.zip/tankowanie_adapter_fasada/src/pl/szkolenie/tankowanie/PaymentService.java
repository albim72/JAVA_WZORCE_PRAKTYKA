package pl.szkolenie.tankowanie;

/**
 * Prosty serwis płatności.
 */
public class PaymentService {

    public boolean pay(double amount) {
        System.out.printf("Płatność zaakceptowana: %.2f zł%n", amount);
        return true;
    }
}
