package pl.szkolenie.tankowanie;

/**
 * Uruchom tę klasę po uzupełnieniu TODO.
 */
public class Main {

    public static void main(String[] args) {
        OldFuelPump oldPump = new OldFuelPump();

        // Adapter pozwala używać starego dystrybutora jak nowego FuelDispenser.
        FuelDispenser adapter = new FuelPumpAdapter(oldPump);

        PaymentService paymentService = new PaymentService();
        ReceiptPrinter receiptPrinter = new ReceiptPrinter();

        // Fasada upraszcza cały proces tankowania do jednej metody.
        FuelingFacade fuelingFacade = new FuelingFacade(
                adapter,
                paymentService,
                receiptPrinter
        );

        // Przykład testowy:
        // 40 litrów po 6.50 zł/l powinno kosztować 260.00 zł.
        fuelingFacade.fuelCar(40.0, 6.50);
    }
}
