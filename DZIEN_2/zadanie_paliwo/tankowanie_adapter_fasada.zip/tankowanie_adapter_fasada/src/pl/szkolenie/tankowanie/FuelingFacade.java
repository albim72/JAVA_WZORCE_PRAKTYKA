package pl.szkolenie.tankowanie;

/**
 * WZORZEC FASADA
 *
 * Zadanie:
 * Ukryj kilka kroków tankowania za jedną prostą metodą fuelCar(...).
 *
 * Fasada ma:
 * 1. policzyć koszt,
 * 2. pobrać płatność,
 * 3. zatankować paliwo,
 * 4. wydrukować paragon.
 */
public class FuelingFacade {

    private final FuelDispenser fuelDispenser;
    private final PaymentService paymentService;
    private final ReceiptPrinter receiptPrinter;

    public FuelingFacade(FuelDispenser fuelDispenser,
                         PaymentService paymentService,
                         ReceiptPrinter receiptPrinter) {
        this.fuelDispenser = fuelDispenser;
        this.paymentService = paymentService;
        this.receiptPrinter = receiptPrinter;
    }

    public void fuelCar(double liters, double pricePerLiter) {
        // TODO 3: policz całkowity koszt tankowania.
        // total = liters * pricePerLiter

        // TODO 4: wykonaj płatność przez paymentService.pay(...)
        // Jeżeli płatność się nie powiedzie, zakończ metodę.

        // TODO 5: zatankuj paliwo przez fuelDispenser.dispense(...)

        // TODO 6: wydrukuj paragon przez receiptPrinter.print(...)

        throw new UnsupportedOperationException("TODO: uzupełnij Fasade");
    }
}
