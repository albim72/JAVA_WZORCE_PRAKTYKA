package pl.szkolenie.tankowanie;

/**
 * Interfejs, którego oczekuje nasza nowa aplikacja.
 * Chcemy tankować paliwo podając ilość w LITRACH.
 */
public interface FuelDispenser {
    void dispense(double liters);
}
