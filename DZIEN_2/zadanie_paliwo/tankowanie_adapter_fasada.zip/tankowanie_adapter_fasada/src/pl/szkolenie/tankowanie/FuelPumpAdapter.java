package pl.szkolenie.tankowanie;

/**
 * WZORZEC ADAPTER
 *
 * Zadanie:
 * Dopasuj stary dystrybutor OldFuelPump do interfejsu FuelDispenser.
 */
public class FuelPumpAdapter implements FuelDispenser {

    private final OldFuelPump oldFuelPump;

    public FuelPumpAdapter(OldFuelPump oldFuelPump) {
        this.oldFuelPump = oldFuelPump;
    }

    @Override
    public void dispense(double liters) {
        // TODO 1: przelicz litry na galony.
        // Przyjmij: 1 galon = 3.78541 litra.
        // Wzór: gallons = liters / 3.78541

        // TODO 2: wywołaj metodę starego systemu:
        // oldFuelPump.pumpGallons(...)

        throw new UnsupportedOperationException("TODO: uzupełnij Adapter");
    }
}
