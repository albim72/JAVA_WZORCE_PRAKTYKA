package pl.szkolenie.tankowanie;

/**
 * Stary system dystrybutora.
 * Problem: działa w GALONACH, a nasza aplikacja pracuje w LITRACH.
 */
public class OldFuelPump {

    public void pumpGallons(double gallons) {
        System.out.printf("Stary dystrybutor: zatankowano %.2f galonów.%n", gallons);
    }
}
