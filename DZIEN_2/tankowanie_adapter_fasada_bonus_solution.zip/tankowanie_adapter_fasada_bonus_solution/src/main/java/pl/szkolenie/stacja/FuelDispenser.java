package pl.szkolenie.stacja;

/**
 * Interfejs nowego systemu stacji paliw.
 * Nowa aplikacja posługuje się litrami.
 */
public interface FuelDispenser {
    void dispense(double liters);

    double getLastDispensedLiters();
}
