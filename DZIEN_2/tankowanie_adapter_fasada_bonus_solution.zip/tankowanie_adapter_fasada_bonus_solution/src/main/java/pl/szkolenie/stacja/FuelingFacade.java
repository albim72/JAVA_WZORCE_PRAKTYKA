package pl.szkolenie.stacja;

/**
 * FASADA
 * Ukrywa szczegóły całego procesu tankowania:
 * obliczenia, rabat, płatność, tankowanie, odczyt ilości paliwa i paragon.
 */
public class FuelingFacade {

    private final FuelDispenser fuelDispenser;
    private final PaymentService paymentService;
    private final ReceiptPrinter receiptPrinter;

    public FuelingFacade(FuelDispenser fuelDispenser,
                         PaymentService paymentService,
                         ReceiptPrinter receiptPrinter) {
        this.fuelDispenser = fuelDispenser;
        this.paymentService = paymentService;
        this.receiptPrinter = receiptPrinter;
    }

    /**
     * Wersja zgodna z podstawowym zadaniem: karta lojalnościowa = 10% rabatu.
     */
    public void fuelCarWithDiscount(double liters,
                                    double pricePerLiter,
                                    boolean loyaltyCard) {
        CustomerType type = loyaltyCard ? CustomerType.GOLD : CustomerType.STANDARD;
        fuelCar(liters, pricePerLiter, type);
    }

    /**
     * BONUS: obsługa czterech poziomów klienta.
     */
    public void fuelCar(double liters,
                        double pricePerLiter,
                        CustomerType customerType) {

        if (liters <= 0 || pricePerLiter <= 0) {
            System.out.println("Nieprawidłowe dane tankowania.");
            return;
        }

        if (customerType == null) {
            customerType = CustomerType.STANDARD;
        }

        System.out.println("Rozpoczynam tankowanie...");
        System.out.printf("Typ klienta: %s%n", customerType);
        System.out.printf("Rabat: %d%%%n", customerType.getDiscountPercent());

        double priceBeforeDiscount = liters * pricePerLiter;
        double discount = priceBeforeDiscount * customerType.getDiscountRate();
        double finalPrice = priceBeforeDiscount - discount;

        System.out.printf("Cena przed rabatem: %.2f zł%n", priceBeforeDiscount);
        System.out.printf("Do zapłaty: %.2f zł%n", finalPrice);

        if (!paymentService.pay(finalPrice)) {
            System.out.println("Tankowanie przerwane.");
            return;
        }

        fuelDispenser.dispense(liters);

        double actuallyDispensedLiters = fuelDispenser.getLastDispensedLiters();
        System.out.printf("Adapter potwierdza wydanie: %.2f l.%n", actuallyDispensedLiters);

        receiptPrinter.print(
                actuallyDispensedLiters,
                pricePerLiter,
                priceBeforeDiscount,
                finalPrice,
                customerType
        );

        System.out.println("Tankowanie zakończone.");
    }
}
