package pl.szkolenie.stacja;

/**
 * Odpowiada za wydruk paragonu.
 */
public class ReceiptPrinter {

    public void print(double liters,
                      double pricePerLiter,
                      double priceBeforeDiscount,
                      double paidAmount,
                      CustomerType customerType) {

        System.out.println();
        System.out.println("===== PARAGON =====");
        System.out.printf("Paliwo: %.2f l%n", liters);
        System.out.printf("Cena za litr: %.2f zł%n", pricePerLiter);
        System.out.printf("Cena przed rabatem: %.2f zł%n", priceBeforeDiscount);
        System.out.printf("Klient: %s%n", customerType);
        System.out.printf("Rabat: %d%%%n", customerType.getDiscountPercent());
        System.out.printf("Zapłacono: %.2f zł%n", paidAmount);
        System.out.println("===================");
        System.out.println();
    }
}
