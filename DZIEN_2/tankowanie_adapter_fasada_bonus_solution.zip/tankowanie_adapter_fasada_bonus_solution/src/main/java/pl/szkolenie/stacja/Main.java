package pl.szkolenie.stacja;

public class Main {

    public static void main(String[] args) {
        OldFuelPump oldPump = new OldFuelPump();

        FuelDispenser dispenser = new FuelPumpAdapter(oldPump);
        PaymentService paymentService = new PaymentService();
        ReceiptPrinter receiptPrinter = new ReceiptPrinter();

        FuelingFacade station = new FuelingFacade(
                dispenser,
                paymentService,
                receiptPrinter
        );

        // BONUS: wybieramy poziom klienta.
        station.fuelCar(
                62,
                7.89,
                CustomerType.GOLD
        );
    }
}
