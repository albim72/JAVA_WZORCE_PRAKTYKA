package pl.szkolenie.stacja;

/**
 * Stary system dystrybutora paliwa.
 * Urządzenie działa w galonach i nie zna pojęcia litrów.
 */
public class OldFuelPump {

    private double lastPumpedGallons;

    public void pumpGallons(double gallons) {
        lastPumpedGallons = gallons;
        System.out.printf("Stary dystrybutor wydaje %.2f galonów paliwa.%n", gallons);
    }

    public double getLastPumpedGallons() {
        return lastPumpedGallons;
    }
}
