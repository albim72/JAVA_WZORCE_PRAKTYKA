package pl.szkolenie.stacja;

/**
 * Prosty serwis płatności.
 */
public class PaymentService {

    public boolean pay(double amount) {
        if (amount <= 0) {
            System.out.println("Płatność odrzucona: nieprawidłowa kwota.");
            return false;
        }

        System.out.printf("Płatność zaakceptowana: %.2f zł.%n", amount);
        return true;
    }
}
