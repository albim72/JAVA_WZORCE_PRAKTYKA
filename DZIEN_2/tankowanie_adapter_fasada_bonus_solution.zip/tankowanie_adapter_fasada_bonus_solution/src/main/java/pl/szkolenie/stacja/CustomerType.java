package pl.szkolenie.stacja;

/**
 * BONUS: poziomy programu lojalnościowego.
 */
public enum CustomerType {
    STANDARD(0.00),
    SILVER(0.05),
    GOLD(0.10),
    VIP(0.15);

    private final double discountRate;

    CustomerType(double discountRate) {
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public int getDiscountPercent() {
        return (int) Math.round(discountRate * 100);
    }
}
