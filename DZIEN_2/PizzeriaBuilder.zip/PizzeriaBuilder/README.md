# PizzeriaBuilder

Przykładowy projekt konsolowy w Java pokazujący wzorzec projektowy **Builder**.

## Wymagania

* Java 17 lub nowsza
* IntelliJ IDEA
* Maven jest opcjonalny, IntelliJ rozpozna projekt z pliku `pom.xml`

## Uruchomienie w IntelliJ IDEA

1. Rozpakuj ZIP.
2. W IntelliJ wybierz **File -> Open**.
3. Wskaż katalog `PizzeriaBuilder`.
4. Jeżeli IntelliJ zapyta o import projektu Maven, zaakceptuj.
5. Otwórz:
`src/main/java/pl/edu/pizzeria/builder/PizzeriaApp.java`
6. Kliknij zielony trójkąt przy metodzie `main`.
7. W konsoli wybierz:

   * `1` aby zbudować własną pizzę,
   * `2` aby zamówić pizzę z gotowego przepisu,
   * `0` aby zakończyć program.

## Najważniejszy fragment Buildera

```java
Pizza pizza = new Pizza.Builder("Moja Pizza")
        .size(Size.LARGE)
        .dough(Dough.THIN)
        .sauce(Sauce.TOMATO)
        .extraCheese(true)
        .addTopping(Topping.MOZZARELLA)
        .addTopping(Topping.SALAMI)
        .build();
```

## Role we wzorcu

* `Pizza` - Product
* `Pizza.Builder` - Builder / Concrete Builder
* `PizzaDirector` - Director (opcjonalny)
* `PizzeriaApp` - Client
* `Size`, `Dough`, `Sauce`, `Topping` - typy opisujące konfigurację produktu

## Po co Builder?

Bez Buildera konstruktor mógłby wyglądać np. tak:

```java
new Pizza("Moja Pizza", Size.LARGE, Dough.THIN, Sauce.TOMATO, true, toppings);
```

Przy większej liczbie parametrów kod staje się trudny do czytania i podatny na błędy.

Builder pozwala budować obiekt krok po kroku i nadaje parametrom nazwy poprzez nazwy metod.

## 

