package pl.edu.pizzeria.builder;

public enum Sauce {
    TOMATO,
    GARLIC,
    BBQ;

    @Override
    public String toString() {
        return switch (this) {
            case TOMATO -> "pomidorowy";
            case GARLIC -> "czosnkowy";
            case BBQ -> "BBQ";
        };
    }
}
