package pl.edu.pizzeria.builder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Produkt tworzony przez wzorzec Builder.
 *
 * Pizza jest niemutowalna:
 * - pola są final,
 * - nie ma setterów,
 * - jedyny sposób utworzenia obiektu to Pizza.Builder.
 */
public final class Pizza {

    private final String name;
    private final Size size;
    private final Dough dough;
    private final Sauce sauce;
    private final boolean extraCheese;
    private final List<Topping> toppings;

    private Pizza(Builder builder) {
        this.name = builder.name;
        this.size = builder.size;
        this.dough = builder.dough;
        this.sauce = builder.sauce;
        this.extraCheese = builder.extraCheese;
        this.toppings = Collections.unmodifiableList(
                new ArrayList<>(builder.toppings)
        );
    }

    public String getName() {
        return name;
    }

    public Size getSize() {
        return size;
    }

    public Dough getDough() {
        return dough;
    }

    public Sauce getSauce() {
        return sauce;
    }

    public boolean hasExtraCheese() {
        return extraCheese;
    }

    public List<Topping> getToppings() {
        return toppings;
    }

    public double calculatePrice() {
        double price = size.getBasePrice();

        if (dough == Dough.STUFFED_CRUST) {
            price += 6.00;
        }

        if (extraCheese) {
            price += 4.00;
        }

        price += toppings.size() * 3.50;
        return price;
    }

    @Override
    public String toString() {
        return """
                ------------------------------
                PIZZA: %s
                Rozmiar: %s
                Ciasto: %s
                Sos: %s
                Dodatkowy ser: %s
                Dodatki: %s
                Cena: %.2f zł
                ------------------------------
                """.formatted(
                name,
                size,
                dough,
                sauce,
                extraCheese ? "TAK" : "NIE",
                toppings.isEmpty() ? "brak" : toppings,
                calculatePrice()
        );
    }

    /**
     * BUILDER
     *
     * Builder zbiera parametry krok po kroku.
     * Dopiero build() tworzy właściwy obiekt Pizza.
     */
    public static class Builder {

        private final String name;

        private Size size = Size.MEDIUM;
        private Dough dough = Dough.THIN;
        private Sauce sauce = Sauce.TOMATO;
        private boolean extraCheese = false;
        private final List<Topping> toppings = new ArrayList<>();

        /**
         * Parametr wymagany podajemy w konstruktorze Buildera.
         */
        public Builder(String name) {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("Nazwa pizzy nie może być pusta.");
            }
            this.name = name;
        }

        public Builder size(Size size) {
            this.size = size;
            return this;
        }

        public Builder dough(Dough dough) {
            this.dough = dough;
            return this;
        }

        public Builder sauce(Sauce sauce) {
            this.sauce = sauce;
            return this;
        }

        public Builder extraCheese(boolean extraCheese) {
            this.extraCheese = extraCheese;
            return this;
        }

        public Builder addTopping(Topping topping) {
            this.toppings.add(topping);
            return this;
        }

        /**
         * Ostatni krok budowania.
         * Tu można wykonywać walidację reguł biznesowych.
         */
        public Pizza build() {
            if (size == null) {
                throw new IllegalStateException("Rozmiar pizzy jest wymagany.");
            }

            if (dough == null) {
                throw new IllegalStateException("Rodzaj ciasta jest wymagany.");
            }

            if (sauce == null) {
                throw new IllegalStateException("Sos jest wymagany.");
            }

            return new Pizza(this);
        }
    }
}
