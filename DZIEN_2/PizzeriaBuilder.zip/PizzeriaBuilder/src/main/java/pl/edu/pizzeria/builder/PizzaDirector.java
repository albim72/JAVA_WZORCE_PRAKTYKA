package pl.edu.pizzeria.builder;

/**
 * Opcjonalny "Director" z klasycznej interpretacji wzorca Builder.
 *
 * Zna gotowe przepisy i używa Buildera do ich zbudowania.
 * Klient nie musi znać kolejności ani kompletu składników.
 */
public final class PizzaDirector {

    private PizzaDirector() {
    }

    public static Pizza margherita() {
        return new Pizza.Builder("Margherita")
                .size(Size.MEDIUM)
                .dough(Dough.CLASSIC)
                .sauce(Sauce.TOMATO)
                .addTopping(Topping.MOZZARELLA)
                .build();
    }

    public static Pizza pepperoni() {
        return new Pizza.Builder("Pepperoni")
                .size(Size.LARGE)
                .dough(Dough.THIN)
                .sauce(Sauce.TOMATO)
                .extraCheese(true)
                .addTopping(Topping.MOZZARELLA)
                .addTopping(Topping.SALAMI)
                .build();
    }

    public static Pizza hawaiian() {
        return new Pizza.Builder("Hawajska")
                .size(Size.MEDIUM)
                .dough(Dough.CLASSIC)
                .sauce(Sauce.TOMATO)
                .addTopping(Topping.MOZZARELLA)
                .addTopping(Topping.HAM)
                .addTopping(Topping.PINEAPPLE)
                .build();
    }
}
