package pl.edu.pizzeria.builder;

public enum Topping {
    MOZZARELLA,
    HAM,
    SALAMI,
    MUSHROOMS,
    OLIVES,
    ONION,
    JALAPENO,
    PINEAPPLE;

    @Override
    public String toString() {
        return switch (this) {
            case MOZZARELLA -> "mozzarella";
            case HAM -> "szynka";
            case SALAMI -> "salami";
            case MUSHROOMS -> "pieczarki";
            case OLIVES -> "oliwki";
            case ONION -> "cebula";
            case JALAPENO -> "jalapeño";
            case PINEAPPLE -> "ananas";
        };
    }
}
