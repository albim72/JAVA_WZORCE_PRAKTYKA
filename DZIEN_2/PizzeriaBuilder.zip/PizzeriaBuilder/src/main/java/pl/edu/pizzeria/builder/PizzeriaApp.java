package pl.edu.pizzeria.builder;

import java.util.Scanner;

public class PizzeriaApp {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("====================================");
        System.out.println("      PIZZERIA - BUILDER DEMO");
        System.out.println("====================================");

        boolean running = true;

        while (running) {
            printMainMenu();

            int choice = readInt("Wybierz opcję: ");

            switch (choice) {
                case 1 -> createCustomPizza();
                case 2 -> showReadyPizzaMenu();
                case 0 -> running = false;
                default -> System.out.println("Nieprawidłowa opcja.");
            }
        }

        System.out.println("Dziękujemy za wizytę w pizzerii! 🍕");
    }

    private static void printMainMenu() {
        System.out.println();
        System.out.println("1. Zbuduj własną pizzę");
        System.out.println("2. Zamów pizzę z gotowego przepisu");
        System.out.println("0. Wyjście");
    }

    private static void createCustomPizza() {

        System.out.println();
        System.out.println("=== WŁASNA PIZZA ===");

        System.out.print("Podaj nazwę swojej pizzy: ");
        String name = scanner.nextLine();

        Pizza.Builder builder = new Pizza.Builder(name);

        builder.size(readSize());
        builder.dough(readDough());
        builder.sauce(readSauce());

        System.out.print("Dodatkowy ser? (t/n): ");
        String cheese = scanner.nextLine().trim();
        builder.extraCheese(cheese.equalsIgnoreCase("t"));

        addToppings(builder);

        Pizza pizza = builder.build();

        System.out.println();
        System.out.println("Twoja pizza została zbudowana:");
        System.out.println(pizza);
    }

    private static void showReadyPizzaMenu() {

        System.out.println();
        System.out.println("=== GOTOWE PIZZE ===");
        System.out.println("1. Margherita");
        System.out.println("2. Pepperoni");
        System.out.println("3. Hawajska");

        int choice = readInt("Wybierz pizzę: ");

        Pizza pizza = switch (choice) {
            case 1 -> PizzaDirector.margherita();
            case 2 -> PizzaDirector.pepperoni();
            case 3 -> PizzaDirector.hawaiian();
            default -> null;
        };

        if (pizza == null) {
            System.out.println("Nieprawidłowa opcja.");
            return;
        }

        System.out.println();
        System.out.println("Zamówiono:");
        System.out.println(pizza);
    }

    private static Size readSize() {
        System.out.println();
        System.out.println("Rozmiar:");
        System.out.println("1. Mała");
        System.out.println("2. Średnia");
        System.out.println("3. Duża");

        return switch (readInt("Wybierz: ")) {
            case 1 -> Size.SMALL;
            case 3 -> Size.LARGE;
            default -> Size.MEDIUM;
        };
    }

    private static Dough readDough() {
        System.out.println();
        System.out.println("Ciasto:");
        System.out.println("1. Cienkie");
        System.out.println("2. Klasyczne");
        System.out.println("3. Z serem w brzegach");

        return switch (readInt("Wybierz: ")) {
            case 1 -> Dough.THIN;
            case 3 -> Dough.STUFFED_CRUST;
            default -> Dough.CLASSIC;
        };
    }

    private static Sauce readSauce() {
        System.out.println();
        System.out.println("Sos:");
        System.out.println("1. Pomidorowy");
        System.out.println("2. Czosnkowy");
        System.out.println("3. BBQ");

        return switch (readInt("Wybierz: ")) {
            case 2 -> Sauce.GARLIC;
            case 3 -> Sauce.BBQ;
            default -> Sauce.TOMATO;
        };
    }

    private static void addToppings(Pizza.Builder builder) {

        boolean adding = true;

        while (adding) {
            System.out.println();
            System.out.println("Dodatki:");
            System.out.println("1. Mozzarella");
            System.out.println("2. Szynka");
            System.out.println("3. Salami");
            System.out.println("4. Pieczarki");
            System.out.println("5. Oliwki");
            System.out.println("6. Cebula");
            System.out.println("7. Jalapeño");
            System.out.println("8. Ananas");
            System.out.println("0. Koniec dodawania");

            int choice = readInt("Wybierz dodatek: ");

            switch (choice) {
                case 1 -> builder.addTopping(Topping.MOZZARELLA);
                case 2 -> builder.addTopping(Topping.HAM);
                case 3 -> builder.addTopping(Topping.SALAMI);
                case 4 -> builder.addTopping(Topping.MUSHROOMS);
                case 5 -> builder.addTopping(Topping.OLIVES);
                case 6 -> builder.addTopping(Topping.ONION);
                case 7 -> builder.addTopping(Topping.JALAPENO);
                case 8 -> builder.addTopping(Topping.PINEAPPLE);
                case 0 -> adding = false;
                default -> System.out.println("Nieprawidłowa opcja.");
            }
        }
    }

    private static int readInt(String message) {
        while (true) {
            System.out.print(message);

            String input = scanner.nextLine();

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Wpisz liczbę.");
            }
        }
    }
}
