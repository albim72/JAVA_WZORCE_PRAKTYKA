package pl.edu.pizzeria.builder;

public enum Dough {
    THIN,
    CLASSIC,
    STUFFED_CRUST;

    @Override
    public String toString() {
        return switch (this) {
            case THIN -> "cienkie";
            case CLASSIC -> "klasyczne";
            case STUFFED_CRUST -> "z serem w brzegach";
        };
    }
}
