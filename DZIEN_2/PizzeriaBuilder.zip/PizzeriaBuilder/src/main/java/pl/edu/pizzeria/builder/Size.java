package pl.edu.pizzeria.builder;

public enum Size {
    SMALL(20.00),
    MEDIUM(26.00),
    LARGE(32.00);

    private final double basePrice;

    Size(double basePrice) {
        this.basePrice = basePrice;
    }

    public double getBasePrice() {
        return basePrice;
    }

    @Override
    public String toString() {
        return switch (this) {
            case SMALL -> "mała";
            case MEDIUM -> "średnia";
            case LARGE -> "duża";
        };
    }
}
