package pl.training.delivery.delivery;

public class CourierDelivery implements Delivery {

    @Override
    public void deliver(String address) {
        // TODO KURSANT:
        // Wyświetl komunikat:
        // "Kurier dostarcza przesyłkę pod adres: " + address
        System.out.println("TODO: CourierDelivery.deliver()");
    }
}
