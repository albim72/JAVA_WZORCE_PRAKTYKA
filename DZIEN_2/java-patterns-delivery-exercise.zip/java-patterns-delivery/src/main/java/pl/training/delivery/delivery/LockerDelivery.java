package pl.training.delivery.delivery;

public class LockerDelivery implements Delivery {

    @Override
    public void deliver(String address) {
        // TODO KURSANT:
        // Wyświetl komunikat:
        // "Przesyłka została wysłana do paczkomatu: " + address
        System.out.println("TODO: LockerDelivery.deliver()");
    }
}
