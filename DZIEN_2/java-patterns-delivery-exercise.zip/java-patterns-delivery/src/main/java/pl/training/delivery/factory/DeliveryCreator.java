package pl.training.delivery.factory;

import pl.training.delivery.delivery.Delivery;

public abstract class DeliveryCreator {

    public abstract Delivery createDelivery();
}
