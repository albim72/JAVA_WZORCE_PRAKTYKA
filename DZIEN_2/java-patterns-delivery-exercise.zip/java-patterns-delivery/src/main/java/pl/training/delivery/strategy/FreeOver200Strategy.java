package pl.training.delivery.strategy;

public class FreeOver200Strategy implements PriceStrategy {

    @Override
    public double calculate(double orderValue) {
        // TODO KURSANT:
        // Jeśli wartość zamówienia >= 200 zł, zwróć 0 zł.
        // W przeciwnym przypadku zwróć 15 zł.
        return 0;
    }
}
