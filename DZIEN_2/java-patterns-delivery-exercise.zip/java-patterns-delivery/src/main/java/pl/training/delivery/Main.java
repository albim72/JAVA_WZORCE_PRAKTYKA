package pl.training.delivery;

import pl.training.delivery.delivery.Delivery;
import pl.training.delivery.factory.CourierDeliveryCreator;
import pl.training.delivery.factory.DeliveryCreator;
import pl.training.delivery.strategy.FreeOver200Strategy;
import pl.training.delivery.strategy.PriceStrategy;

public class Main {

    public static void main(String[] args) {

        double orderValue = 250.0;
        String address = "Lublin, ul. Testowa 10";

        // =============================
        // FACTORY METHOD
        // =============================

        DeliveryCreator creator = new CourierDeliveryCreator();

        // TODO KURSANT:
        // Po uzupełnieniu CourierDeliveryCreator poniższa linia
        // powinna zwrócić działający obiekt dostawy.
        Delivery delivery = creator.createDelivery();


        // =============================
        // STRATEGY
        // =============================

        PriceStrategy strategy = new FreeOver200Strategy();


        // =============================
        // POŁĄCZENIE WZORCÓW
        // =============================

        // TODO KURSANT:
        // Gdy Factory Method zostanie poprawnie uzupełnione,
        // usuń poniższy warunek zabezpieczający i uruchom OrderService.
        if (delivery == null) {
            System.out.println("TODO: uzupełnij Factory Method w klasach Creator.");
            return;
        }

        OrderService orderService = new OrderService(delivery, strategy);
        orderService.processOrder(orderValue, address);

        // TODO KURSANT:
        // Dodaj co najmniej 2 kolejne testy z inną dostawą
        // i inną strategią cenową.
    }
}
