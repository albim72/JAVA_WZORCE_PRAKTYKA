package pl.training.delivery.strategy;

public class StandardPriceStrategy implements PriceStrategy {

    @Override
    public double calculate(double orderValue) {
        // TODO KURSANT:
        // Standardowa dostawa kosztuje 15 zł.
        return 0;
    }
}
