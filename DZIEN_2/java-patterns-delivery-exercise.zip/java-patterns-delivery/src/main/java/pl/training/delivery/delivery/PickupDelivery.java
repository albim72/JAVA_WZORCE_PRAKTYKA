package pl.training.delivery.delivery;

public class PickupDelivery implements Delivery {

    @Override
    public void deliver(String address) {
        // TODO KURSANT:
        // Wyświetl komunikat:
        // "Zamówienie czeka na odbiór osobisty"
        System.out.println("TODO: PickupDelivery.deliver()");
    }
}
