package pl.training.delivery;

import pl.training.delivery.delivery.Delivery;
import pl.training.delivery.strategy.PriceStrategy;

public class OrderService {

    private final Delivery delivery;
    private final PriceStrategy priceStrategy;

    public OrderService(Delivery delivery, PriceStrategy priceStrategy) {
        this.delivery = delivery;
        this.priceStrategy = priceStrategy;
    }

    public void processOrder(double orderValue, String address) {
        double deliveryPrice = priceStrategy.calculate(orderValue);

        System.out.println("Wartość zamówienia: " + orderValue + " zł");
        System.out.println("Koszt dostawy: " + deliveryPrice + " zł");
        delivery.deliver(address);
    }
}
