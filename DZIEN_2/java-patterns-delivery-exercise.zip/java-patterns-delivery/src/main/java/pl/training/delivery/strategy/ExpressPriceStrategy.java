package pl.training.delivery.strategy;

public class ExpressPriceStrategy implements PriceStrategy {

    @Override
    public double calculate(double orderValue) {
        // TODO KURSANT:
        // Dostawa ekspresowa kosztuje 30 zł.
        return 0;
    }
}
