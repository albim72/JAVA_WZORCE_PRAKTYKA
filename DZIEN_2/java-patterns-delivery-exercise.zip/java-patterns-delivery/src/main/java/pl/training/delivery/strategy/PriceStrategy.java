package pl.training.delivery.strategy;

public interface PriceStrategy {

    double calculate(double orderValue);
}
