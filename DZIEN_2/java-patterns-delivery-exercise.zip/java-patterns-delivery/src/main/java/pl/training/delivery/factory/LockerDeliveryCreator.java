package pl.training.delivery.factory;

import pl.training.delivery.delivery.Delivery;

public class LockerDeliveryCreator extends DeliveryCreator {

    @Override
    public Delivery createDelivery() {
        // TODO KURSANT:
        // Zwróć nowy obiekt LockerDelivery.
        return null;
    }
}
