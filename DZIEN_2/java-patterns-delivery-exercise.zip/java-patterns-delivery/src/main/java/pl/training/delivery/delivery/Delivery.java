package pl.training.delivery.delivery;

public interface Delivery {

    void deliver(String address);
}
