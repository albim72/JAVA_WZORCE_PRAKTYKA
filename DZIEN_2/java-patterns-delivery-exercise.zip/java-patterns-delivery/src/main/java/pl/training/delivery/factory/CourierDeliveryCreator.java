package pl.training.delivery.factory;

import pl.training.delivery.delivery.Delivery;

public class CourierDeliveryCreator extends DeliveryCreator {

    @Override
    public Delivery createDelivery() {
        // TODO KURSANT:
        // Zwróć nowy obiekt CourierDelivery.
        return null;
    }
}
