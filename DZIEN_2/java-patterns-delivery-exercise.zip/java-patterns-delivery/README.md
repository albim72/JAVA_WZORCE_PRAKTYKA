# Zadanie: System dostawy zamówień

## Cel ćwiczenia

Połącz dwa wzorce projektowe w jednym praktycznym przykładzie:

- **Factory Method** — wzorzec kreacyjny,
- **Strategy** — wzorzec behawioralny.

Projekt przedstawia uproszczony system sklepu internetowego. System ma tworzyć różne sposoby dostawy oraz niezależnie dobierać sposób obliczania kosztu dostawy.

## Scenariusz biznesowy

Sklep obsługuje trzy sposoby dostawy:

1. kurier,
2. paczkomat,
3. odbiór osobisty.

Koszt dostawy może być liczony według trzech strategii:

1. standardowa — 15 zł,
2. ekspresowa — 30 zł,
3. darmowa od 200 zł — 0 zł dla zamówienia >= 200 zł, w przeciwnym razie 15 zł.

## Zadanie kursanta

Uzupełnij wszystkie miejsca oznaczone komentarzem:

```java
// TODO KURSANT
```

### Część 1 — Delivery

Uzupełnij klasy:

- `CourierDelivery`,
- `LockerDelivery`,
- `PickupDelivery`.

Każda klasa powinna implementować metodę `deliver(...)`.

### Część 2 — Factory Method

Uzupełnij klasy:

- `CourierDeliveryCreator`,
- `LockerDeliveryCreator`,
- `PickupDeliveryCreator`.

Każda fabryka ma tworzyć odpowiedni obiekt typu `Delivery`.

### Część 3 — Strategy

Uzupełnij klasy:

- `StandardPriceStrategy`,
- `ExpressPriceStrategy`,
- `FreeOver200Strategy`.

Każda strategia ma zwracać właściwy koszt dostawy.

### Część 4 — uruchomienie programu

W klasie `Main` przetestuj co najmniej trzy kombinacje, np.:

- kurier + standardowa cena,
- paczkomat + ekspresowa cena,
- kurier + darmowa dostawa od 200 zł.

## Oczekiwany przykład działania

Dla zamówienia o wartości 250 zł, dostawy kurierskiej i strategii `FreeOver200Strategy` wynik może wyglądać tak:

```text
Wartość zamówienia: 250.0 zł
Koszt dostawy: 0.0 zł
Kurier dostarcza przesyłkę pod adres: Lublin, ul. Testowa 10
```

## Pytania do omówienia

1. Za co odpowiada Factory Method w tym projekcie?
2. Za co odpowiada Strategy?
3. Co trzeba dodać, jeśli sklep wprowadzi dostawę dronem?
4. Co trzeba dodać, jeśli sklep wprowadzi nową strategię cenową dla klientów VIP?
5. Dlaczego lepiej rozdzielić tworzenie obiektów od sposobu obliczania ceny?

## Uruchomienie w IntelliJ IDEA

1. Otwórz IntelliJ IDEA.
2. Wybierz **Open**.
3. Wskaż katalog projektu.
4. IntelliJ powinien rozpoznać `pom.xml` jako projekt Maven.
5. Upewnij się, że projekt używa JDK 17 lub nowszego.
6. Uruchom klasę `Main`.

Projekt jest celowo niekompletny, ale kompiluje się. Część metod zwraca wartości zastępcze lub wypisuje komunikaty `TODO`.
